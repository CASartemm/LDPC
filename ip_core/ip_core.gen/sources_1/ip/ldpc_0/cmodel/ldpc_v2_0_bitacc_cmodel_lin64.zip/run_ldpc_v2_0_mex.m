% (c) Copyright 2016 Xilinx, Inc. All rights reserved.
%
% This file contains confidential and proprietary information
% of Xilinx, Inc. and is protected under U.S. and
% international copyright and other intellectual property
% laws.
%
% DISCLAIMER
% This disclaimer is not a license and does not grant any
% rights to the materials distributed herewith. Except as
% otherwise provided in a valid license issued to you by
% Xilinx, and to the maximum extent permitted by applicable
% law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
% WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
% AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
% BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
% INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
% (2) Xilinx shall not be liable (whether in contract or tort,
% including negligence, or under any other theory of
% liability) for any loss or damage of any kind or nature
% related to, arising under or in connection with these
% materials, including for any direct, or any indirect,
% special, incidental, or consequential loss or damage
% (including loss of data, profits, goodwill, or any type of
% loss or damage suffered as a result of any action brought
% by a third party) even if such damage or loss was
% reasonably foreseeable or Xilinx had been advised of the
% possibility of the same.
%
% CRITICAL APPLICATIONS
% Xilinx products are not designed or intended to be fail-
% safe, or for use in any application requiring fail-safe
% performance, such as life-support or safety devices or
% systems, Class III medical devices, nuclear facilities,
% applications related to the deployment of airbags, or any
% other applications that could lead to death, personal
% injury, or severe property or environmental damage
% (individually and collectively, "Critical
% Applications"). Customer assumes the sole risk and
% liability of any use of Xilinx products in Critical
% Applications, subject only to applicable laws and
% regulations governing limitations on product liability.
%
% THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
% PART OF THIS FILE AT ALL TIMES.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all;

% Create instances
cnfg.name='LDPC Decoder';
cnfg.operation = 0; % 0 = Decode 1 = Encode
dec = ldpc_v2_0_bitacc(cnfg);
cnfg.name='LDPC Encoder';
cnfg.operation = 1;
enc = ldpc_v2_0_bitacc(cnfg);

% Generate LDPC parameters and add to engine
fprintf('Generate LDPC parameters....\n');
load test.mat;                        % Load parity check matrix (H)
h_size = size(h);
k = h_size(2) - h_size(1);
gen_ldpc_spec(h,psize,'spec.yml');    % Generate specification file, unnecessary if specification file available
% add_ldpc_params(dec,0,'test.yml');      % Add LDPC code to model
% add_ldpc_params(enc,0,'test.yml');      % Add LDPC code to model
add_ldpc_params(dec,0,'spec.yml');      % Add LDPC code to models
add_ldpc_params(enc,0,'spec.yml');      % Add LDPC code to models

% Confirm matrix to specification conversion
h_ref = gen_parity_check_mat('spec.yml'); % Load parity check matrix from reference specification
if sum(sum(h-h_ref)) > 0
  error('Error in read back matrix');
end

% Encode
fprintf('Encode....\n');

% Define control packet
ctrl.code           = 0;   % Select LDPC code, identifier defined by add_ldpc_params

bits=double(rand(1,k)>0.5);

% Run engine
[encbits,stats]=process(enc,ctrl,bits);

% Convert to LLRs and corrupt some bits
llrbits = 16 * ((2*double(encbits))-1);

llrbits(10) = -llrbits(10);
llrbits(1024) = -llrbits(1024);

err_bits = sum(abs(bits - (llrbits(1:k).'>=0)));
fprintf('Errors introduced: %d\n',err_bits);

% Decode
fprintf('Decode....\n');

ctrl.code              = 0;   % Select LDPC code, identifier defined by add_ldpc_params
ctrl.hard_op           = 1;   % Hard o/p
ctrl.max_iterations    = 8;   % Max iterations (decode only)
ctrl.id                = 0;   % User ID
ctrl.term_on_pass      = 1;   % Terminate on parity pass
ctrl.term_on_no_change = 0;   % Terminate if hard decision of codeword does not change between iterations

% Run engine
[decbits,stats]=process(dec,ctrl,llrbits);
fprintf('Decoder iterations: %d\n',stats.dec_iter);

% Determine number of bits in error
err_bits = sum(abs(bits - double(decbits(1:k).')));
fprintf('Errors after decode: %d\n',err_bits);

% Check decoder has done some work
if (stats.dec_iter == 2 && err_bits == 0) disp('Test completed successfully'); end

%-----------------------------------------------------------------------------
%  (c) Copyright 2016 Xilinx, Inc. All rights reserved.
%
%  This file contains confidential and proprietary information
%  of Xilinx, Inc. and is protected under U.S. and
%  international copyright and other intellectual property
%  laws.
%
%  DISCLAIMER
%  This disclaimer is not a license and does not grant any
%  rights to the materials distributed herewith. Except as
%  otherwise provided in a valid license issued to you by
%  Xilinx, and to the maximum extent permitted by applicable
%  law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
%  WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
%  AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
%  BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
%  INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
%  (2) Xilinx shall not be liable (whether in contract or tort,
%  including negligence, or under any other theory of
%  liability) for any loss or damage of any kind or nature
%  related to, arising under or in connection with these
%  materials, including for any direct, or any indirect,
%  special, incidental, or consequential loss or damage
%  (including loss of data, profits, goodwill, or any type of
%  loss or damage suffered as a result of any action brought
%  by a third party) even if such damage or loss was
%  reasonably foreseeable or Xilinx had been advised of the
%  possibility of the same.
%
%  CRITICAL APPLICATIONS
%  Xilinx products are not designed or intended to be fail-
%  safe, or for use in any application requiring fail-safe
%  performance, such as life-support or safety devices or
%  systems, Class III medical devices, nuclear facilities,
%  applications related to the deployment of airbags, or any
%  other applications that could lead to death, personal
%  injury, or severe property or environmental damage
%  (individually and collectively, "Critical
%  Applications"). Customer assumes the sole risk and
%  liability of any use of Xilinx products in Critical
%  Applications, subject only to applicable laws and
%  regulations governing limitations on product liability.
%
%  THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
%  PART OF THIS FILE AT ALL TIMES.
%-----------------------------------------------------------------------------
