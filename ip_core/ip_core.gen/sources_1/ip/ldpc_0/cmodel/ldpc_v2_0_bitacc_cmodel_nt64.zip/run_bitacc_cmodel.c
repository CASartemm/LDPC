//-----------------------------------------------------------------------------
// (c) Copyright 2016 Xilinx, Inc. All rights reserved.
//
// This file contains confidential and proprietary information
// of Xilinx, Inc. and is protected under U.S. and
// international copyright and other intellectual property
// laws.
//
// DISCLAIMER
// This disclaimer is not a license and does not grant any
// rights to the materials distributed herewith. Except as
// otherwise provided in a valid license issued to you by
// Xilinx, and to the maximum extent permitted by applicable
// law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
// WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
// AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
// BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
// INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
// (2) Xilinx shall not be liable (whether in contract or tort,
// including negligence, or under any other theory of
// liability) for any loss or damage of any kind or nature
// related to, arising under or in connection with these
// materials, including for any direct, or any indirect,
// special, incidental, or consequential loss or damage
// (including loss of data, profits, goodwill, or any type of
// loss or damage suffered as a result of any action brought
// by a third party) even if such damage or loss was
// reasonably foreseeable or Xilinx had been advised of the
// possibility of the same.
//
// CRITICAL APPLICATIONS
// Xilinx products are not designed or intended to be fail-
// safe, or for use in any application requiring fail-safe
// performance, such as life-support or safety devices or
// systems, Class III medical devices, nuclear facilities,
// applications related to the deployment of airbags, or any
// other applications that could lead to death, personal
// injury, or severe property or environmental damage
// (individually and collectively, "Critical
// Applications"). Customer assumes the sole risk and
// liability of any use of Xilinx products in Critical
// Applications, subject only to applicable laws and
// regulations governing limitations on product liability.
//
// THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
// PART OF THIS FILE AT ALL TIMES.
//-----------------------------------------------------------------------------

#include "ldpc_v2_0_bitacc_cmodel.h"
#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <math.h>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>

//---------------------------------------------------------------------------------------------------------------------
// Transaction log dump functions

// Writes a stream of bytes (in hex), least significant byte first.
std::string dump_axis(unsigned long in, int bytes=4) {
  std::string ret_str = "";
   for (int i=0;i<bytes;i++) {
    std::stringstream frmt;
    frmt << std::hex << std::setw(2) << std::setfill('0') << std::uppercase;
    frmt << (0x00FF & in);
    in = in >> 8;
    ret_str += frmt.str();
  }
  return ret_str;
}

void dump_block(std::ofstream&               DAT_FILE,
                xip_uint                     operation,
                xip_uint                     standard,
                xip_ldpc_v2_0_ctrl_packet&   ctrl,
                xip_uint                     din_words,
                xip_uint                     num_din_words,
                xip_uint                     dout_words,
                xip_uint                     num_dout_words,
                xip_array_real*              din,
                xip_ldpc_v2_0_stat_packet&   stats,
                xip_array_bit*               dout_hard,
                xip_array_real*              dout_soft) {
  char byte[2];
  unsigned long word = 0;
  unsigned int ctrl_bytes = 4;
  unsigned int stat_bytes = 4;

  // Control
  if (standard == XIP_LDPC_v2_0_STANDARD_5G) {
    ctrl_bytes = 5;
    word += (unsigned long)pow(2,0) * ctrl.z_j;
    word += (unsigned long)pow(2,3) * ctrl.z_set;
    word += (unsigned long)pow(2,6) * ctrl.bg;
    word += (unsigned long)pow(2,9) * ctrl.sc_idx;
    word += (unsigned long)pow(2,32) * ctrl.mb;
  } else {
    word += ctrl.code;
  }
  word += (unsigned long)pow(2,14) * ctrl.hard_op;
  word += (unsigned long)pow(2,15) * ctrl.include_parity_op;
  word += (unsigned long)pow(2,16) * ctrl.term_on_pass;
  word += (unsigned long)pow(2,17) * ctrl.term_on_no_change;
  word += (unsigned long)pow(2,18) * ctrl.max_iterations;
  DAT_FILE << "CTRL " << dump_axis(word,ctrl_bytes) << std::endl;

  // Status
  word = 0;
  if (standard == XIP_LDPC_v2_0_STANDARD_5G) {
    stat_bytes = 5;
    word += (unsigned long)pow(2,0) * stats.z_j;
    word += (unsigned long)pow(2,3) * stats.z_set;
    word += (unsigned long)pow(2,6) * stats.bg;
    word += (unsigned long)pow(2,32) * stats.mb;
  } else {
    word += stats.code;
  }
  word += (unsigned long)pow(2,14) * stats.hard_op;
  word += (unsigned long)pow(2,15) * stats.pass;
  word += (unsigned long)pow(2,16) * stats.term_pass;
  word += (unsigned long)pow(2,17) * stats.term_no_change;
  word += (unsigned long)pow(2,18) * stats.dec_iter;
  DAT_FILE << "STATUS " << dump_axis(word,stat_bytes) << std::endl;

  // Data in
  std::vector<unsigned int> words;
  unsigned int word_count  = 0;
  DAT_FILE << "DIN ";
  if (operation == XIP_LDPC_v2_0_ENCODE) {
    // Encoder, hard i/p
    // o Build packed hard bit values
    for (int i=0;i<din->data_size;i+=8) {
      word = 0;
      for (int j=0;j<8 && j+i<din->data_size;j++) {
        word += ((xip_uint)pow(2,j) * (xip_uint)din->data[i+j]);
      }
      DAT_FILE << dump_axis(word,1);
      //
      word_count++;
      if (din_words != 0 && (word_count == num_din_words || i>=din->data_size-1)) {
        words.push_back(num_din_words); // One per transaction
        word_count = 0;
      }
    }
  } else {
    // Soft i/p
    // o 8-bits per soft value
    for (int i=0;i<din->data_size;i++) {
      // WARNING: Using a fixed binpt to scale real input values
      DAT_FILE << dump_axis( int(din->data[i] * 4),1);
      word_count++;
      if (din_words != 0 && (word_count == num_din_words || i==din->data_size-1) ) {
        words.push_back(num_din_words); // One per transaction
        word_count = 0;
      }
    }
  }
  DAT_FILE << std::endl;

  // DIN WORDS
  DAT_FILE << "DIN_WORDS ";
  if (din_words == 0) {
    words.push_back(num_din_words); // One per block
  }
  for (std::vector<unsigned int>::iterator i = words.begin(); i != words.end(); ++i) {
    DAT_FILE << dump_axis(*i,1); // 8-bit values for each din word value
  }
  DAT_FILE << std::endl;

  // Data out
  words.clear();
  word_count  = 0;
  DAT_FILE << "DOUT ";
  if (stats.hard_op && dout_hard) {
    // Hard o/p
    // o Build packed hard bit values
    for (int i=0;i<dout_hard->data_size;i+=8) {
      word = 0;
      for (int j=0;j<8 && j+i<dout_hard->data_size;j++) {
        word += ((xip_uint)pow(2,j) * dout_hard->data[i+j]);
      }
      DAT_FILE << dump_axis(word,1);
      //
      word_count++;
      if (dout_words != 0 && (word_count == num_dout_words || i>=dout_hard->data_size-1)) {
        words.push_back(num_dout_words); // One per transaction
        word_count = 0;
      }
    }

  } else if (dout_soft) {
    // Soft o/p
    // o 8-bits per soft value
    for (int i=0;i<dout_soft->data_size;i++) {
      // WARNING: Using a fixed binpt to scale real input values
      DAT_FILE << dump_axis( int(dout_soft->data[i] * 4),1);
      //
      word_count++;
      if (dout_words != 0 && (word_count == num_dout_words || i==dout_soft->data_size-1)) {
        words.push_back(num_dout_words); // One per transaction
        word_count = 0;
      }
    }
  }
  DAT_FILE << std::endl;

  // DOUT WORDS
  DAT_FILE << "DOUT_WORDS ";
  if (dout_words == 0) {
    words.push_back(num_dout_words); // One per block
  }
  for (std::vector<unsigned int>::iterator i = words.begin(); i != words.end(); ++i) {
    DAT_FILE << dump_axis(*i,1); // 8-bit values for each din word value
  }
  DAT_FILE << std::endl;

}

//---------------------------------------------------------------------------------------------------------------------
// Example message handler
static void msg_print(void* handle, int error, const char* msg)
{
  std::cout << "MSG: " << msg << std::endl;
}

//---------------------------------------------------------------------------------------------------------------------
// Run a number of code blocks through model instances
int run_blocks(unsigned int               num_blocks,
               unsigned int               standard,
               xip_ldpc_v2_0*             encoder,
               xip_ldpc_v2_0*             decoder,
               xip_ldpc_v2_0_ctrl_packet& ctrl,
               std::ofstream&             DAT_FILE) {

  // Fetch code parameters to determine packet sizes
  xip_ldpc_v2_0_ldpc_parameters params;
  xip_ldpc_v2_0_get_ldpc_params(decoder,&ctrl,&params);

  // Create data structures
  xip_array_real* bin = xip_array_real_create();
  xip_array_real_reserve_dim(bin,1);
  bin->dim_size = 1;
  bin->dim[0] = params.k;
  bin->data_size = bin->dim[0];
  if (xip_array_real_reserve_data(bin,bin->data_size) == XIP_STATUS_ERROR) {
    std::cout << "Failed to reserve data array" << std::endl;
    return 1;
  } else {
    std::cout << "Reserved bin data" << std::endl;
  }

  xip_array_bit* encb = xip_array_bit_create();

  xip_array_real* llr = xip_array_real_create();
  xip_array_real_reserve_dim(llr,1);
  llr->dim_size = 1;
  llr->dim[0] = params.n;
  llr->data_size = llr->dim[0];
  if (xip_array_real_reserve_data(llr,llr->data_size) == XIP_STATUS_ERROR) {
    std::cout << "Failed to reserve data array" << std::endl;
    return 1;
  } else {
    std::cout << "Reserved llr data" << std::endl;
  }

  xip_array_bit* decb = xip_array_bit_create();

  std::cout << "Block "
            << "Input Errors "
            << "Output Errors "
            << "Iter "
            << "Max. Iter "
            << "Pass "
            << "Term on pass "
            << std::endl;

  block_loop: for (int block=0;block<num_blocks;block++) {

    // Create input bits
    for (int i=0;i<params.k;i++) {
      if (rand()%100 > 50) {
        bin->data[i] = 1;
      } else {
        bin->data[i] = 0;
      }
    }

    // Set non-code selection control parameters
    // o Code selection parameters set external to function
    ctrl.hard_op           = 1;
    ctrl.include_parity_op = 0;
    ctrl.max_iterations    = 8;
    ctrl.id                = 0;
    ctrl.term_on_pass      = 1;
    ctrl.term_on_no_change = 0;

    xip_ldpc_v2_0_stat_packet stat;

    if (xip_ldpc_v2_0_process(encoder,&ctrl,bin,encb,NULL,&stat) == XIP_STATUS_ERROR) {
      std::cout << "Failed to encode" << std::endl;
      return 1;
    }
    // dump_block(DAT_FILE,XIP_LDPC_v2_0_ENCODE,standard,ctrl,0,16,0,16,bin,stat,encb,NULL);

    // Corrupt encoded bits and convert to LLRs
    int err_target = rand()%100;
    int err_bits   = 0;
    for (int i=0;i<params.n;i++) {
      if (encb->data[i]==0) {
        llr->data[i] = -4; // Fix6_2
      } else {
        llr->data[i] = 4;
      }
      if (err_bits != err_target) {
        if (rand()%100 > 90) {
          llr->data[i] = -1 * llr->data[i];
          err_bits++;
        }
      }
    }

    // Modify control structure for decode
    ctrl.hard_op        = 1;
    ctrl.max_iterations = 8;
    ctrl.id             = 1;

    if (xip_ldpc_v2_0_process(decoder,&ctrl,llr,decb,NULL,&stat) == XIP_STATUS_ERROR) {
      std::cout << "Failed to decode" << std::endl;
      return 1;
    }
    dump_block(DAT_FILE,XIP_LDPC_v2_0_DECODE,standard,ctrl,0,16,0,16,llr,stat,decb,NULL);

    // Compare inputs to outputs
    int num_errors = 0;
    for(int i=0;i<params.k;i++) {
      if (decb->data[i] != bin->data[i]) {
        num_errors++;
      }
    }

    std::cout << std::setiosflags(std::ios::left)
              << std::setw(6)  << block
              << std::setw(13) << err_bits
              << std::setw(14) << num_errors
              << std::setw(5)  << stat.dec_iter
              << std::setw(10) << ctrl.max_iterations
              << std::setw(5)  << (int)stat.pass
              << std::setw(13) << (int)stat.term_pass
              << std::endl;
  }

  // Tidy up
  xip_array_real_destroy(bin);
  xip_array_real_destroy(llr);
  xip_array_bit_destroy(encb);
  xip_array_bit_destroy(decb);

  return 0;
}


int main () {

  std::ofstream DAT_FILE; // Output file for transaction log
  xip_ldpc_v2_0_ldpc_parameters params;

  std::cout << "LDPC C model version: " << xip_ldpc_v2_0_get_version() << std::endl;

  std::cout << "Example 1: Custom LDPC code ..." << std::endl;

  DAT_FILE.open("test_trans.log");

  xip_ldpc_v2_0_config config;
  config.name                     = "LDPC Decoder";
  config.operation                = XIP_LDPC_v2_0_DECODE;
  config.standard                 = XIP_LDPC_v2_0_STANDARD_OTHER;
  config.algorithm                = XIP_LDPC_v2_0_ALGORITHM_NORMALIZED_MINSUM;
  config.packing                  = 1;
  config.output_parity_check      = 1;
  config.scale_override           = XIP_LDPC_v2_0_SCALE_OVERRIDE_DISABLED;
  config.ldpc_code_initialization = "test.yml"; // Initialize C model with code definition
  config.bypass                   = 0;
  config.ip_quant_mode            = 0; //0 = Quantize and saturate to Decoder LLR limits, 1 = Quantize and wrap at input width limits as per H/W

  xip_ldpc_v2_0* decoder = xip_ldpc_v2_0_create(&config,&msg_print,0);
  if (!decoder) {
    std::cout << "Failed to create Decoder instance" << std::endl;
    return 1;
  }
  std::cout << "Number of codes available in decoder: " <<  xip_ldpc_v2_0_get_num_ldpc_codes(decoder) << std::endl;

  // Add an additional code following model creation
  // o Using the same specification as used for initialization, this will add the same code to the LDPC
  if (xip_ldpc_v2_0_gen_ldpc_params(decoder,"test.yml",&params,&msg_print,0) == XIP_LDPC_v2_0_LDPC_CODE_ERROR) {
    std::cout << "ERROR: Error reading specification yaml" << std::endl;
    return 1;
  }
  // Select the next available code ID
  // o Location 0 populated by initialization, can be overwritten if desired
  if (xip_ldpc_v2_0_add_ldpc_params(decoder,1,&params) == XIP_STATUS_ERROR) {
    std::cout << "Failed to add LDPC code parameters to Decoder" << std::endl;
    return 1;
  } else {
    std::cout << "Added LDPC code parameters" << std::endl;
  }
  xip_ldpc_v2_0_destroy_ldpc_params(&params,&msg_print,0);
  std::cout << "Number of codes available in decoder: " <<  xip_ldpc_v2_0_get_num_ldpc_codes(decoder) << std::endl;

  config.name                     = "LDPC Encoder";
  config.operation                = XIP_LDPC_v2_0_ENCODE;
  config.ldpc_code_initialization = NULL; // Disable initialization for Encoder instance

  xip_ldpc_v2_0* encoder = xip_ldpc_v2_0_create(&config,&msg_print,0);
  if (!encoder) {
    std::cout << "Failed to create Encoder instance" << std::endl;
    return 1;
  }

  if (xip_ldpc_v2_0_gen_ldpc_params(encoder,"test.yml",&params,&msg_print,0) == XIP_LDPC_v2_0_LDPC_CODE_ERROR) {
    std::cout << "ERROR: Error reading specification yaml" << std::endl;
    return 1;
  }
  if (xip_ldpc_v2_0_add_ldpc_params(encoder,0,&params) == XIP_STATUS_ERROR) {
    std::cout << "Failed to add LDPC code parameters to Encoder" << std::endl;
    return 1;
  } else {
    std::cout << "Added LDPC code parameters" << std::endl;
  }
  xip_ldpc_v2_0_destroy_ldpc_params(&params,&msg_print,0);
  std::cout << "Number of codes available in encoder: " <<  xip_ldpc_v2_0_get_num_ldpc_codes(encoder) << std::endl;

  xip_ldpc_v2_0_ctrl_packet ctrl;
  // Select code to in control packet to run test using
  // o run_blocks function will set the other ctrl fields
  ctrl.code = 0;
  run_blocks(10,XIP_LDPC_v2_0_STANDARD_OTHER,encoder,decoder,ctrl,DAT_FILE);

  xip_ldpc_v2_0_destroy(decoder);
  xip_ldpc_v2_0_destroy(encoder);

  DAT_FILE.close();

  std::cout << "Example 2: Using a supported standard ..." << std::endl;
  // Note, re-using already declared variables

  config.name                     = "LDPC Decoder";
  config.operation                = XIP_LDPC_v2_0_DECODE;
  config.standard                 = XIP_LDPC_v2_0_STANDARD_WIFI_802_11;
  config.algorithm                = XIP_LDPC_v2_0_ALGORITHM_NORMALIZED_MINSUM;
  config.packing                  = 1;
  config.output_parity_check      = 0;
  config.scale_override           = 14; // Override default scaling factor, 14 * 0.065 = 0.875
  config.ldpc_code_initialization = NULL;
  config.bypass                   = 0;
  config.ip_quant_mode            = 0; //0 = Quantize and saturate to Decoder LLR limits, 1 = Quantize and wrap at input width limits as per H/W

  decoder = xip_ldpc_v2_0_create(&config,&msg_print,0);
  if (!decoder) {
    std::cout << "Failed to create Decoder instance" << std::endl;
    return 1;
  }
  std::cout << "Number of codes available in decoder: " <<  xip_ldpc_v2_0_get_num_ldpc_codes(decoder) << std::endl;

  config.name                     = "LDPC Encoder";
  config.operation                = XIP_LDPC_v2_0_ENCODE;

  encoder = xip_ldpc_v2_0_create(&config,&msg_print,0);
  if (!encoder) {
    std::cout << "Failed to create Encoder instance" << std::endl;
    return 1;
  }
  std::cout << "Number of codes available in encoder: " <<  xip_ldpc_v2_0_get_num_ldpc_codes(encoder) << std::endl;

  // Select code and run blocks
  ctrl.code = 3; // wifi802_11_cr2_3_648
  run_blocks(10,XIP_LDPC_v2_0_STANDARD_WIFI_802_11,encoder,decoder,ctrl,DAT_FILE);

  xip_ldpc_v2_0_destroy(decoder);
  xip_ldpc_v2_0_destroy(encoder);

  std::cout << "Example 3: 5G configuration ..." << std::endl;

  DAT_FILE.open("test_trans_5g.log");

  config.name                     = "LDPC Decoder";
  config.operation                = XIP_LDPC_v2_0_DECODE;
  config.standard                 = XIP_LDPC_v2_0_STANDARD_5G;
  config.algorithm                = XIP_LDPC_v2_0_ALGORITHM_NORMALIZED_MINSUM;
  config.packing                  = 1;
  config.output_parity_check      = 0;
  config.scale_override           = XIP_LDPC_v2_0_SCALE_OVERRIDE_DISABLED;
  config.ldpc_code_initialization = NULL;
  config.bypass                   = 0;
  config.ip_quant_mode            = 0; //0 = Quantize and saturate to Decoder LLR limits, 1 = Quantize and wrap at input width limits as per H/W

  decoder = xip_ldpc_v2_0_create(&config,&msg_print,0);
  if (!decoder) {
    std::cout << "Failed to create Decoder instance" << std::endl;
    return 1;
  }

  config.name                     = "LDPC Encoder";
  config.operation                = XIP_LDPC_v2_0_ENCODE;

  encoder = xip_ldpc_v2_0_create(&config,&msg_print,0);
  if (!encoder) {
    std::cout << "Failed to create Encoder instance" << std::endl;
    return 1;
  }

  // Select code and then run blocks
  ctrl.z_j    = 4;
  ctrl.z_set  = 0;
  ctrl.bg     = 0;
  ctrl.sc_idx = 13; // 13 * 0.0625 = 0.8125
  ctrl.mb     = 46;
  run_blocks(10,XIP_LDPC_v2_0_STANDARD_5G,encoder,decoder,ctrl,DAT_FILE);

  DAT_FILE.close();

  xip_ldpc_v2_0_destroy(decoder);
  xip_ldpc_v2_0_destroy(encoder);

  return 0;
}
